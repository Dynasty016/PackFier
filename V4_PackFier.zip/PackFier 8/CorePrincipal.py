﻿from flask import Flask, render_template, request, jsonify #Utilizar flask e obter acesso aos arquivos de template. (render_template)
#from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, unset_jwt_cookies #Utilizar os cookies > JSON
import random

#pip.main(["install", "--user", "Flask-JWT-Extended"]) #Instalar o modulo responsável por lidar com os cookies.

import pyodbc #Modulo do SQL

app = Flask(__name__)

#SQL#
dados_conexao = (
    "Driver={SQL Server};"
    "Server=localhost\\SQLEXPRESS;"
    "Database=PACKFIER;"
)



#COOKIES#
tipo_tokens = ["C", "F"]
tokens = ["TESTE", "VAZIO"] #Tokens que serão armazenados
dados = [] #Dados que serão armazenados
split_ = "::"



##################
#----CADASTRO----#
##################

@app.route("/") #Localização da página (Padrão|N/A = "/")
def home():
    return render_template('Home.html') #Abrir o documento para a página em HTML.


###############
#----LOGIN----#
###############

@app.route("/login") #Localização da página (Padrão|N/A = "/")
def login():
    return render_template('Login.html') #Abrir o documento para a página em HTML.


###################
#----POS-LOGIN----#
###################

@app.route("/home") #Localização da página (Padrão|N/A = "/")
def p_l():
    return render_template('Pos_login.html') #Abrir o documento para a página em HTML.


#############################
#----CADASTRO-FORNECEDOR----#
#############################

@app.route("/cadastro-f") #Localização da página (Padrão|N/A = "/")
def cadastro_f():
    return render_template('Cadastro_F.html') #Abrir o documento para a página em HTML.


##########################
#----LOGIN-FORNECEDOR----#
##########################

@app.route("/login-f") #Localização da página (Padrão|N/A = "/")
def login_f():
    return render_template('Login_F.html') #Abrir o documento para a página em HTML.


##############################
#----POS-LOGIN-FORNECEDOR----#
##############################

@app.route("/home-f") #Localização da página (Padrão|N/A = "/")
def p_l_f():
    return render_template('Pos_login_fornecedor.html') #Abrir o documento para a página em HTML.


##################
#----RASTREIO----#
##################

@app.route("/rastreio") #Localização da página (Padrão|N/A = "/")
def rastreio():
    return render_template('Rastreio.html') #Abrir o documento para a página em HTML.





#######################################################################################





###################
#----CADASTRAR----#
###################

@app.route("/cadastrar", methods=['POST']) #Localização da página (Padrão|N/A = "/")
def c_c():
    conteudo = request.get_json() #Obter o request do JSon.

    conn = pyodbc.connect(dados_conexao) #puxando os dados de conexao da variavel dados_conexao
    cursor = conn.cursor()

    #Obter os dados de cada input para as variáveis pelo JSon.
    nome = conteudo.get('nome', '')
    sobrenome = conteudo.get('sobrenome', '')
    email = conteudo.get('email', '')
    senha = conteudo.get('senha', '')

    #Retornar sucesso ou erro e mostrar os dados.
    if nome.strip() == '' or sobrenome.strip() == '' or email.strip() == '' or senha.strip() == '':
        print('\nHá campos que não foram preenchidos. (Cadastro)')
        print(f"========================\nNome: {nome}\nSobrenome: {sobrenome}\nEmail: {email}\nSenha: {senha}\n========================\n")
        return "Erro!"
    else:
        print('\nTodos os campos foram preenchidos. (Cadastro)')
        print(f"========================\nNome: {nome}\nSobrenome: {sobrenome}\nEmail: {email}\nSenha: {senha}\n========================\n")

        try:
            sql_query = "INSERT INTO CLIENTES (NOME, SOBRENOME, EMAIL, SENHA) VALUES (?, ?, ?, ?)"
            cursor.execute(sql_query, (nome, sobrenome, email, senha))
            conn.commit()
            conn.close()
            return "Sucesso!"
        except Exception as e:
            print(e)
            return f"Erro: {str(e)}"


########################
#----REALIZAR-LOGIN----#
########################

@app.route("/login", methods=['POST']) #Localização da página (Padrão|N/A = "/")
def c_l():
    conteudo = request.get_json() #Obter o request do JSon.

    conn = pyodbc.connect(dados_conexao) #puxando os dados de conexao da variavel dados_conexao
    cursor = conn.cursor()

    #Obter os dados de cada input para as variáveis pelo JSon.
    email = conteudo.get('email', '')
    senha = conteudo.get('senha', '')

    #token = gerar_token(200)
    #return jsonify(token)


    #Retornar sucesso ou erro e mostrar os dados.
    if email.strip() == '' or senha.strip() == '':
        print('\nHá campos que não foram preenchidos. (Login)')
        print(f"========================\nEmail: {email}\nSenha: {senha}\n========================\n")
        return "Erro!"
    else:
        print('\nTodos os campos foram preenchidos. (Login)')
        print(f"========================\nEmail: {email}\nSenha: {senha}\n========================\n")
    try:
        conn = pyodbc.connect(dados_conexao) 
        cursor = conn.cursor()
        sql_query = "SELECT * FROM CLIENTES WHERE EMAIL = ? AND SENHA = ?"
        print(f"Executando consulta SQL: {sql_query}")
        cursor.execute(sql_query, (email, senha))
        row = cursor.fetchone()
        print("Resultado da consulta:", row)
        conn.close()
        if row:
            token = gerar_token(200)
            gerenciar_dados(1, split_, token, email)
            return jsonify(token)
            #access_token = create_access_token(identity=email)
            #return jsonify(access_token=access_token), 200
        else:
            return "Erro: Credenciais inválidas. Não foram encontrados clientes com essas informações."
    except Exception as e:
        return f"Erro: {str(e)}"


##############################
#----CADASTRAR-FORNECEDOR----#
##############################

@app.route("/cadastrar-f", methods=['POST']) #Localização da página (Padrão|N/A = "/")
def f_c():
    conteudo = request.get_json() #Obter o request do JSon.

    conn = pyodbc.connect(dados_conexao) #puxando os dados de conexao da variavel dados_conexao
    cursor = conn.cursor()

    #Obter os dados de cada input para as variáveis pelo JSon.
    nome = conteudo.get('nome', '')
    cnpj = conteudo.get('cnpj', '')
    email = conteudo.get('email', '')
    senha = conteudo.get('senha', '')

    #Retornar sucesso ou erro e mostrar os dados.
    if nome.strip() == '' or cnpj.strip() == '' or email.strip() == '' or senha.strip() == '':
        print('\nHá campos que não foram preenchidos. (Cadastro-Fornecedor)')
        print(f"========================\nNome: {nome}\nCnpj: {cnpj}\nEmail: {email}\nSenha: {senha}\n========================\n")
        return "Erro!"
    else:
        print('\nTodos os campos foram preenchidos. (Cadastro-Fornecedor)')
        print(f"========================\nNome: {nome}\nCnpj: {cnpj}\nEmail: {email}\nSenha: {senha}\n========================\n")

        try:
            sql_query = "INSERT INTO FORNECEDOR (NOME, CNPJ, SENHA, EMAIL) VALUES (?, ?, ?, ?)"
            cursor.execute(sql_query, (nome, cnpj, senha, email))
            conn.commit()
            conn.close()
            return "Sucesso!"
        except Exception as e:
            print(e)
            return f"Erro: {str(e)}"



###################################
#----REALIZAR-LOGIN-FORNECEDOR----#
###################################

@app.route("/login-f", methods=['POST'])
def f_l():
    conteudo = request.get_json()  # Obter o request do JSON.

    conn = pyodbc.connect(dados_conexao)  # Puxando os dados de conexao da variavel dados_conexao
    cursor = conn.cursor()

    # Obter os dados de cada input para as variáveis pelo JSON.
    cnpj = conteudo.get('cnpj', '')
    senha = conteudo.get('senha', '')
        
    # Retornar sucesso ou erro e mostrar os dados.
    if cnpj.strip() == '' or senha.strip() == '':
        print('\nHá campos que não foram preenchidos. (Login-Fornecedor)')
        print(f"========================\nCnpj: {cnpj}\nSenha: {senha}\n========================\n")
        return "Erro!", 400
    else:
        print('\nTodos os campos foram preenchidos. (Login-Fornecedor)')
        print(f"========================\nCnpj: {cnpj}\nSenha: {senha}\n========================\n")
    
    try:
        sql_query = "SELECT CNPJ, SENHA FROM FORNECEDOR WHERE CNPJ = ? AND SENHA = ?"
        print(f"Executando consulta SQL: {sql_query}")
        cursor.execute(sql_query, (cnpj, senha))
        row = cursor.fetchone()
        print("Resultado da consulta:", row)
        conn.close()

        if row:
            token = gerar_token(200)
            gerenciar_dados(1, split_, token, cnpj)
            return jsonify(token=token), 200
        else:
            return "Erro: Credenciais inválidas. Não foram encontrados clientes com essas informações.", 401
    except Exception as e:
        print(f"Erro durante a execução da consulta: {e}")
        return "Erro no servidor", 500


@app.route('/logout', methods=['POST'])
def logout():
    unset_jwt_cookies()
    return jsonify({"msg": "Logout bem-sucedido"}), 200



#############################
#----PESQUISAR-REGISTROS----#
#############################

@app.route("/rastrear", methods=['POST'])
def r():
    conteudo = request.get_json() # Obter o request do JSON.

    dados = { # Dados que o sistema irá operar junto com o SQL.
        "ID": "?",
        "DESCRICAO": "?",
        "TIPO": "?"
    }

    conn = pyodbc.connect(dados_conexao) # Puxando os dados de conexão da variável dados_conexao
    cursor = conn.cursor()

    # Obter os dados de cada input para as variáveis pelo JSON.
    codigo = conteudo.get('codigo', '')

    # Retornar sucesso ou erro e mostrar os dados.
    if codigo.strip() == '':
        print('\nHá campos que não foram preenchidos. (Rastreio)')
        print(f"========================\nCodigo: {codigo}\n========================\n")
        return "Erro: Campos não preenchidos!"
    else:
        print('\nTodos os campos foram preenchidos. (Rastreio)')
        print(f"========================\nCodigo: {codigo}\n========================\n")

        # Executando o SQl
        try:
            cursor.execute("SELECT COD_COMPRA, DESCRICAO, TIPO FROM COMPRA WHERE RASTREIO = ?", (codigo,))
            row = cursor.fetchone()

            if row:
                dados['ID'] = row[0]
                dados['DESCRICAO'] = row[1]
                dados['TIPO'] = row[2]
            else:
                print("Nenhum resultado encontrado para o código:", codigo)
                # Se nenhum resultado for encontrado, enviar uma mensagem de erro personalizada
                return jsonify({"error": "Não foi possível encontrar uma encomenda com base no código de rastreio fornecido!"}), 404

        except Exception as e:
            print("Erro ao executar a consulta SQL:", str(e))
            return jsonify({"error": "Erro ao executar a consulta SQL"}), 500

        # Retornar os dados em formato JSON
        return jsonify(dados)


##########################
#----CADASTRAR-PACOTE----#
##########################

@app.route("/novo-pacote", methods=['POST'])
def n_p():
    conteudo = request.get_json()  # Obter o request do JSON.

    conn = pyodbc.connect(dados_conexao)  # Puxando os dados de conexão da variável dados_conexao
    cursor = conn.cursor()

    # Obter os dados de cada input para as variáveis pelo JSON.
    pacote = conteudo.get('pacote', '')
    nome_cliente = conteudo.get('nome_cliente', '')
    tipo = conteudo.get('tipo', '')
    desc = conteudo.get('desc', '')

    # Retornar sucesso ou erro e mostrar os dados.
    if pacote.strip() == '' or nome_cliente.strip() == '' or tipo.strip() == '' or desc.strip() == '':
        print('\nHá campos que não foram preenchidos. (Criar-Pacote)')
        print(f"========================\nPacote: {pacote}\nQnt: {tipo}\nCliente: {nome_cliente}\nDescrição: {desc}\n========================\n")
        return "Erro!"
    else:
        print('\nTodos os campos foram preenchidos. (Criar-Pacote)')
        print(f"========================\nPacote: {pacote}\nTipo: {tipo}\nCliente: {nome_cliente}\nDescrição: {desc}\n========================\n")

        try:
            # Código SQL para gerar um código de rastreio aleatório
            sql_code = """
            DECLARE @Characters TABLE (
                char_value CHAR(1) PRIMARY KEY
            );

            DECLARE @char_value CHAR(1);
            DECLARE @result VARCHAR(25) = '';
            DECLARE @guid UNIQUEIDENTIFIER;
            DECLARE @char_set NVARCHAR(36) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

            WHILE (SELECT COUNT(*) FROM @Characters) < 5
            BEGIN
                SET @guid = NEWID();

                SET @char_value = SUBSTRING(@char_set, ABS(CHECKSUM(SUBSTRING(CAST(@guid AS VARBINARY), 1, 1))) % 36 + 1, 1);
                
                IF NOT EXISTS (SELECT 1 FROM @Characters WHERE char_value = @char_value)
                BEGIN
                    INSERT INTO @Characters (char_value) VALUES (@char_value);
                END;
            END;

            SELECT @result = STRING_AGG(char_value, '')
            FROM @Characters
            ORDER BY NEWID();

            INSERT INTO COMPRA (PACOTE, NOME_CLIENTE, TIPO, DESCRICAO, RASTREIO)
            VALUES (?, ?, ?, ?, @result);
            """

            # Executar o código SQL
            cursor.execute(sql_code, (pacote, nome_cliente, tipo, desc))
            conn.commit()
            conn.close()
            
            return "Sucesso!"
        except Exception as e:
            print(e)
            return f"Erro: {str(e)}"





#######################################################
#--------------------TOKENS-CONFIG--------------------#
#######################################################


#Cria um novo token aleatório. (Login)
def gerar_token(tamanho):
    texto = ""
    distancia = 25

    for i in range(tamanho):
        valor = random.randint(65, (65+distancia))
        
        if (random.randint(1, 2)) == 1:
            valor = (valor+32)
            
        texto = texto+chr(valor)

    tokens.append(texto)
    print("Token criado! ("+texto+")\nTamanho utilizado: "+str(tamanho)+"\n")
    return texto



#Verifica se o token existe. (Acesso)
def verificar_por_token(token):
    distancia = 25
    
    if len(tokens) > 0:
        dado_valido = ""

        for char in token:
            if (ord(char) >= 65 and ord(char) <= 65+distancia) or (ord(char) >= (65+32) and ord(char) <= (65+distancia+32)):
                dado_valido = dado_valido+char
                
        for string in tokens:
            if dado_valido == string:
                print("Token encontrado! ("+dado_valido+")\n")
                return True

    print("Token não encontrado ou não registrado! ("+dado_valido+")\n")
    return False



#Remove o token escolhido. (Logoff)
def remover_token(token):
    distancia = 25
    
    if len(tokens) > 0:
        index = 0
        dado_valido = ""

        for char in token:
            if (ord(char) >= 65 and ord(char) <= 65+distancia) or (ord(char) >= (65+32) and ord(char) <= (65+distancia+32)):
                dado_valido = dado_valido+char
        
        for string in tokens:
            if dado_valido == string:
                del tokens[index]
                print("Token deletado! ("+dado_valido+")\n")
                return True
            index += 1

    print("Token não encontrado ou não registrado! ("+dado_valido+")\n")
    return False



#Lista todos os tokens.
def listar_tokens():
    if len(tokens) > 0:
        texto = ""
        nl = "\n"
        index = 0
        
        for string in tokens:
            texto = texto+"["+str(index+1)+"] - "+string+nl
            index += 1
        print(texto)
        return True

    return False





#Gerenciamento dos usuários logados. --== Tipo{criar/excluir/pesquisar >> int};  Separador_Texto{string};  Token{string};  Informação_Usuário{string} ==--
def gerenciar_dados(chave, split, token, info):
    distancia = 25
    
    if (len(dados) > 0 or chave <= 1):
        index = 0
        dado_valido = ""

        for char in token:
            if (ord(char) >= 65 and ord(char) <= 65+distancia) or (ord(char) >= (65+32) and ord(char) <= (65+distancia+32)):
                dado_valido = dado_valido+char

        if chave <= 1: #Cria
            if not (split and info):
                print("Os dados não foram fornecidos corretamente.")
                return [False, ""]

            output = (dado_valido+split+info)
            dados.append(output)
            
            print("Registro criado! Usuário = ("+info+")\n")
            return [True, info]
        
        elif chave == 2: #Remove
            for string in dados:
                splitstr = string.split(split)
                
                if len(splitstr) == 2:
                    if dado_valido == splitstr[0]:
                        del dados[index]
                        print("Registro deletado! ("+dado_valido+")\n")
                        return [True, dado_valido]
                index += 1
                
        else: #Pesquisa
            for string in dados:
                splitstr = string.split(split)
                
                if len(splitstr) == 2:
                    if dado_valido == splitstr[0]:
                        return [True, splitstr[1]]
                index += 1


    print("Registro não encontrado ou não existe! ("+token+")\n")
    return [False, ""]





@app.route("/verificar-token", methods=['POST']) #Localização da página (Padrão|N/A = "/")
def v_t():
    conteudo = request.get_json() #Obter o request do JSon.

    token = conteudo.get('token', '')

    if token:
        if token.strip() != '':
            if verificar_por_token(token) == True:
                resultado = gerenciar_dados(3, split_, token, "")

                if (resultado[0] == True and resultado[1].strip() != ''):
                    print("O usuário '"+resultado[1]+"' acessou uma página restrita por login!\n")
                    return jsonify("1")

    return jsonify("0")





@app.route("/logoff", methods=['POST']) #Localização da página (Padrão|N/A = "/")
def l_o():
    conteudo = request.get_json() #Obter o request do JSon.

    token = conteudo.get('token', '')

    if token:
        if token.strip() != '':
            if verificar_por_token(token) == True:
                resultado = gerenciar_dados(3, split_, token, "")

                if (resultado[0] == True and resultado[1].strip() != ''):
                    print("O usuário '"+resultado[1]+"' deslogou de sua conta!\n")
                    gerenciar_dados(2, split_, token, "")
                    remover_token(token)
                    return jsonify("1")

    return jsonify("0")







############################################################
#--------------------SERVER-SIDE-CONFIG--------------------#
############################################################

    
if __name__ == "__main__":
    #app.run(host="0.0.0.0") #Iniciar como host público. (Habilitar o firewall)
    app.run(debug=False) #Iniciar da máquina local.
